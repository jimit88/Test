<?php


const DB_HOST='localhost';
const  DB_USER='root';
const  DB_NAME='social_db';
const DB_PASS='';

$conn=mysqli_connect('DB_HOST','DB_USER','DB_NAME','DB_PASS');

if($conn){
    echo "connected";
}
else{
    echo"not";
}

?>
