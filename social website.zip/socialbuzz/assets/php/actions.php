<?php

require_once 'E:/xampp/htdocs/socialbuzz/assets/php/functions.php';
if(isset($_GET['signup'])){
   $response= validateSignupForm($_POST);
   
   if($response['status']){

   }else{
      $_SESSION['error']=$response;
      header("location:../../");
   }
}
?>


