<?php

include 'assets/pages/signup.php';






if(isset($_GET['signup'])){
    showPage('header');
    showPage('signup');
   
    }

    
?>



<?php
error_reporting(E_ALL);
?>
