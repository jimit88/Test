<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include __DIR__ . '/assets/pages/signup.php';


if(isset($_GET['signup'])){
    showPage('header');
    showPage('signup');
   
    }

    
?>


