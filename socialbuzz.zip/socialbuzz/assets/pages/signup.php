<?php
include __DIR__.'/header.php';
include __DIR__.'/footer.php';
?>

    <div class="login">
        <div class="col-4 bg-white border rounded p-4 shadow-sm">
            <form method="post"  action="assets/php/actions.php?signup">
                <div class="d-flex justify-content-center">

                    <img class="mb-4" src="assets/images/buzz.png" alt="" height="45">
                </div>
                <h1 class="h5 mb-3 fw-normal">Create new account</h1>
                <div class="d-flex">
                    <div class="form-floating mt-1 col-6 ">
                        <input type="text" class="form-control rounded-0" name="first_name" placeholder="Enter Your First Name">
                        <label for="floatingInput">First name</label>
                    </div>
                    
                    <div class="form-floating mt-1 col-6">
                        <input type="text" class="form-control rounded-0"  name="last_name"placeholder="Enter Your Last Name">
                        <label for="floatingInput">Last name</label>
                    </div>
                </div>

                
                <div class="d-flex gap-3 my-3">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios1" value="1" checked="">
                        <label class="form-check-label" for="exampleRadios1">
                            Male
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios3" value="2">
                        <label class="form-check-label" for="exampleRadios3">
                            Female
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios2" value="0">
                        <label class="form-check-label" for="exampleRadios2">
                            Other
                        </label>
                    </div>
                </div>
                <div class="form-floating mt-1">
                    <input type="email" name="email"  class="form-control rounded-0" placeholder="email">
                    <label for="floatingInput">Email</label>
                </div>
                <div class="form-floating mt-1">
                    <input type="text"  name="username" class="form-control rounded-0" placeholder="username">
                    <label for="floatingInput">Username</label>
                </div>
                <div class="form-floating mt-1">
                    <input type="password" name="pass" class="form-control rounded-0" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>

                <div class="mt-3 d-flex justify-content-between align-items-center">
                    <button class="btn btn-primary" type="submit">Sign Up</button>
                    <a href="#" class="text-decoration-none">Already have an account ?</a>


                </div>

            </form>
        </div>
    </div>

    <?php
    if(isset($_POST['submit'])){
      $first_name = $_POST['first_name'];
      $last_name = $_POST['last_name'];
      $gender = $_POST['gender'];
      $uname = $_POST['username'];
      $pass = $_POST['password'];

        $query = "INSERT INTO signup(`first_name`, `last_name`, `gender`, `email`, `username`, `password`) VALUES ('$first_name', '$last_name', '$gender', '$email', '$uname', '$pass')";
        $data=mysqli_query($conn,$query);
        if ($data) {
            ?>
            <script type="text/javascript">
                alert("data inserted");
                </script>
                <?php
        }
        else{
            ?>
            <script type="text/javascript">
                alert("not inserted!");

            </script>
            <?php
        }
    }
    ?>

