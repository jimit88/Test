<?php
require_once __DIR__.'/functions.php';


if(isset($_GET['signup'])){
   $response= validateSignupForm($_POST);


   if($response['status']){


      $first_name = $_POST['first_name'];
      $last_name = $_POST['last_name'];
      $gender = $_POST['gender'];
      $uname = $_POST['username'];
      $pass = $_POST['pass'];
      $query = "INSERT INTO signup(`first_name`, `last_name`, `gender`, `email`, `username`, `password`,`profile_pic`) VALUES ('$first_name', '$last_name', '$gender', '$email', '$uname', '$pass',0)";
      $data=mysqli_query($conn,$query);
      
      header("location:../../");

   }else{
      $_SESSION['error']=$response;
      header("location:../../");
   }
}
?>


