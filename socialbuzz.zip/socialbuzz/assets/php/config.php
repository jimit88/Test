<?php

const DB_HOST='localhost';
const  DB_USER='root';
const  DB_NAME='social_db';
const DB_PASS='toor1';

$conn=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

if($conn){
    echo "DB connected.";
}
else{
    echo"DB not connected.";
}

?>